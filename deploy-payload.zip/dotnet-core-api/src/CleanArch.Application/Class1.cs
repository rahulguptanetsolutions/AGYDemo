﻿namespace CleanArch.Application;

public class Class1
{

}
