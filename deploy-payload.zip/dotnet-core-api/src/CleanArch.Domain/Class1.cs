﻿namespace CleanArch.Domain;

public class Class1
{

}
