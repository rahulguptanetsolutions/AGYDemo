﻿namespace CleanArch.Infrastructure;

public class Class1
{

}
